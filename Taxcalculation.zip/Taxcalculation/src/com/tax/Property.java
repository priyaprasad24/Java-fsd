package com.tax;

class Property {
    private double baseValue;
    private boolean inCity;
    private int ageOfConstruction;

    public Property(double baseValue, boolean inCity, int ageOfConstruction) {
        this.baseValue = baseValue;
        this.inCity = inCity;
        this.ageOfConstruction = ageOfConstruction;
    }

    public double calculatePropertyTax() {
        double tax;
        if (inCity) {
            tax = (2 * ageOfConstruction * baseValue) + (0.5 * baseValue);
        } else {
            tax = ageOfConstruction * baseValue;
        }
        return tax;
    }
}
package com.tax;

import java.util.ArrayList;
import java.util.Scanner;


public class TaxCalculationApp {

    private static final String correctUsername = "priya";
    private static final String correctPassword = "priya123"; 

    public static boolean login() {
        Scanner loginScanner = new Scanner(System.in);
        System.out.println("+========================================+");
        System.out.println("|  Login to Tax Calculation Application  |");
        System.out.println("+========================================+");
        System.out.print("Enter username: ");
        String enteredUsername = loginScanner.nextLine();
        System.out.print("Enter password: ");
        String enteredPassword = loginScanner.nextLine();

        if (enteredUsername.equals(correctUsername) && enteredPassword.equals(correctPassword)) {
            System.out.println("Login successful!");
            return true;
        } else {
            System.out.println("Incorrect username or password. Please try again.");
            return false;
        }
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        ArrayList<Property> properties = new ArrayList<>();
        ArrayList<Vehicle> vehicles = new ArrayList<>();

        if (!login()) {
            System.out.println("Exiting Tax Calculation Application. Goodbye!");
            scanner.close();
            return;
        }

        // Start Tax Calculation Application after successful login
        while (true) {
        	System.out.println("+========================================+");
            System.out.println("| Tax Calculation Application |");
            System.out.println("+========================================+");
            System.out.println("1. Add Property");
            System.out.println("2. Add Vehicle");
            System.out.println("3. Calculate Total Tax");
            System.out.println("4. Exit");
            System.out.println("========================================");
            System.out.print("Enter your choice: ");
            int choice = scanner.nextInt();
            System.out.println("========================================");

            switch (choice) {
            case 1:
                System.out.print("Enter base value of land: ");
                double baseValue = scanner.nextDouble();
                System.out.print("Is the property in the city (Y/N): ");
                boolean inCity = scanner.next().equalsIgnoreCase("Y");
                System.out.print("Enter age of construction: ");
                int ageOfConstruction = scanner.nextInt();
                Property property = new Property(baseValue, inCity, ageOfConstruction);
                properties.add(property);
                System.out.println("Property added successfully.");
                break;
            case 2:
                System.out.print("Enter registration number: ");
                String regNumber = scanner.next();
                System.out.print("Enter brand: ");
                String brand = scanner.next();
                System.out.print("Enter cost: ");
                double cost = scanner.nextDouble();
                System.out.print("Enter velocity: ");
                double velocity = scanner.nextDouble();
                System.out.print("Enter capacity: ");
                int capacity = scanner.nextInt();
                System.out.println("Select vehicle type:");
                System.out.println("1. Petrol-driven");
                System.out.println("2. Diesel-driven");
                System.out.println("3. CNG/LPG-driven");
                int vehicleType = scanner.nextInt();
                Vehicle vehicle = new Vehicle(regNumber, brand, cost, velocity, capacity, vehicleType);
                vehicles.add(vehicle);
                System.out.println("Vehicle added successfully.");
                break;
            case 3:
                double totalPropertyTax = properties.stream().mapToDouble(Property::calculatePropertyTax).sum();
                double totalVehicleTax = vehicles.stream().mapToDouble(Vehicle::calculateVehicleTax).sum();
                double totalTax = totalPropertyTax + totalVehicleTax;
                System.out.println("Total Property Tax: " + totalPropertyTax);
                System.out.println("Total Vehicle Tax: " + totalVehicleTax);
                System.out.println("Total Tax Payable: " + totalTax);
                break;
            case 4:
                System.out.println("Exiting Tax Calculation Application. Goodbye!");
                scanner.close();
                System.exit(0);
            default:
                System.out.println("Invalid choice. Please enter a valid option.");
        }
    }
}
}

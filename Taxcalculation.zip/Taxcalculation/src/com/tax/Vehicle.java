package com.tax;


class Vehicle {
    private String registrationNumber;
    private String brand;
    private double cost;
    private double velocity;
    private int capacity;
    private int vehicleType;

    public Vehicle(String registrationNumber, String brand, double cost, double velocity, int capacity, int vehicleType) {
        this.registrationNumber = registrationNumber;
        this.brand = brand;
        this.cost = cost;
        this.velocity = velocity;
        this.capacity = capacity;
        this.vehicleType = vehicleType;
    }

    public double calculateVehicleTax() {
        double tax;
        switch (vehicleType) {
            case 1:
                tax = velocity + capacity + 0.1 * cost;
                break;
            case 2:
                tax = velocity + capacity + 0.11 * cost;
                break;
            case 3:
                tax = velocity + capacity + 0.12 * cost;
                break;
            default:
                tax = 0.0;
        }
        return tax;
    }
}

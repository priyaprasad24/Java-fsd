package FileCRUD;

import java.io.*;

public class CRUD {
    public static void main(String[] args) {
        // Specify the file path
        String filePath = "sample.txt";

        // Create a new file
        createFile(filePath);

        // Write data to the file
        writeToFile(filePath, "Hello, World!");

        // Read data from the file
        String content = readFromFile(filePath);
        System.out.println("File Content: " + content);

        // Update the file content
        updateFile(filePath, "Updated content!");

        // Read data again to verify the update
        content = readFromFile(filePath);
        System.out.println("Updated File Content: " + content);

        // Delete the file
        deleteFile(filePath);
    }

    // Create a new file
    public static void createFile(String filePath) {
        try {
            File file = new File(filePath);

            if (file.createNewFile()) {
                System.out.println("File created: " + filePath);
            } else {
                System.out.println("File already exists.");
            }
        } catch (IOException e) {
            System.out.println("An error occurred while creating the file: " + e.getMessage());
        }
    }

    // Write data to a file
    public static void writeToFile(String filePath, String data) {
        try (FileWriter writer = new FileWriter(filePath)) {
            writer.write(data);
            System.out.println("Data written to the file.");
        } catch (IOException e) {
            System.out.println("An error occurred while writing to the file: " + e.getMessage());
        }
    }

    // Read data from a file
    public static String readFromFile(String filePath) {
        StringBuilder content = new StringBuilder();
        try (BufferedReader reader = new BufferedReader(new FileReader(filePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                content.append(line).append("\n");
            }
        } catch (IOException e) {
            System.out.println("An error occurred while reading from the file: " + e.getMessage());
        }
        return content.toString();
    }

    // Update data in a file
    public static void updateFile(String filePath, String newData) {
        try (FileWriter writer = new FileWriter(filePath)) {
            writer.write(newData);
            System.out.println("File updated with new data.");
        } catch (IOException e) {
            System.out.println("An error occurred while updating the file: " + e.getMessage());
        }
    }

    // Delete a file
    public static void deleteFile(String filePath) {
        File file = new File(filePath);
        if (file.delete()) {
            System.out.println("File deleted: " + filePath);
        } else {
            System.out.println("Failed to delete the file.");
        }
    }
}



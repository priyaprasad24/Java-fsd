package demonstrateexception;

public class demonstrateexception {
    public static void main(String[] args) {
        try {
            // Attempt to divide by zero
            int result = divide(10, 0);
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            // Catch and handle the ArithmeticException
            System.out.println("ArithmeticException caught: " + e.getMessage());
        }

        try {
            // Attempt to access an array element out of bounds
            int[] arr = { 1, 2, 3 };
            int value = arr[5];
            System.out.println("Value: " + value);
        } catch (ArrayIndexOutOfBoundsException e) {
            // Catch and handle the ArrayIndexOutOfBoundsException
            System.out.println("ArrayIndexOutOfBoundsException caught: " + e.getMessage());
        }

        try {
            // Attempt to parse an invalid integer
            int number = parseInt("abc");
            System.out.println("Parsed number: " + number);
        } catch (NumberFormatException e) {
            // Catch and handle the NumberFormatException
            System.out.println("NumberFormatException caught: " + e.getMessage());
        }

        System.out.println("Program continues after exception handling");
    }

    // A method that can throw an ArithmeticException
    public static int divide(int numerator, int denominator) {
        return numerator / denominator;
    }

    // A method that can throw an ArrayIndexOutOfBoundsException
    public static int accessArrayElement(int[] arr, int index) {
        return arr[index];
    }

    // A method that can throw a NumberFormatException
    public static int parseInt(String str) {
        return Integer.parseInt(str);
    }
}


package DiamondProblem;

//Define a common interface
interface Animal {
 void eat();
}

//Create two interfaces that inherit from Animal
interface Herbivore extends Animal {
 void eatGrass();
}

interface Carnivore extends Animal {
 void eatMeat();
}

//Implement classes that inherit from Herbivore and Carnivore
class Deer implements Herbivore {
 public void eat() {
     System.out.println("Deer is eating.");
 }

 public void eatGrass() {
     System.out.println("Deer is eating grass.");
 }
}

class Lion implements Carnivore {
 public void eat() {
     System.out.println("Lion is eating.");
 }

 public void eatMeat() {
     System.out.println("Lion is eating meat.");
 }
}

//Create a class that inherits from both Herbivore and Carnivore
class OmnivoreAnimal implements Herbivore, Carnivore {
 public void eat() {
     System.out.println("Omnivore is eating.");
 }

 public void eatGrass() {
     System.out.println("Omnivore is eating grass.");
 }

 public void eatMeat() {
     System.out.println("Omnivore is eating meat.");
 }
}

public class DiamondProblem {
 public static void main(String[] args) {
     Deer deer = new Deer();
     Lion lion = new Lion();
     OmnivoreAnimal omnivore = new OmnivoreAnimal();

     deer.eat();
     deer.eatGrass();

     lion.eat();
     lion.eatMeat();

     omnivore.eat();
     omnivore.eatGrass();
     omnivore.eatMeat();
 }
}


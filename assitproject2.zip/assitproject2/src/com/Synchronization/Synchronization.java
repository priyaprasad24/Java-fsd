package com.Synchronization;

class SharedResource {
    private int count = 0;

    // Synchronized method to increment the count
    public synchronized void increment() {
        for (int i = 0; i < 5; i++) {
            count++;
            System.out.println(Thread.currentThread().getName() + " - Incremented: " + count);
        }
    }

	public String getCount() {
		// TODO Auto-generated method stub
		return null;
	}
}

public class Synchronization {
    public static void main(String[] args) {
        SharedResource sharedResource = new SharedResource();

        // Create two threads that increment the shared resource
        Thread thread1 = new Thread(() -> {
            sharedResource.increment();
        });

        Thread thread2 = new Thread(() -> {
            sharedResource.increment();
        });

        // Start both threads
        thread1.start();
        thread2.start();

        try {
            // Wait for both threads to finish
            thread1.join();
            thread2.join();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        System.out.println("Final count: " + sharedResource.getCount());
    }
}


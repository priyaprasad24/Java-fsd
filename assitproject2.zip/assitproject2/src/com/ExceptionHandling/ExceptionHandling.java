package com.ExceptionHandling;

public class ExceptionHandling {
    public static void main(String[] args) {
        try {
         
            int result = divide(10, 0);
            System.out.println("Result: " + result);
        } catch (ArithmeticException e) {
            
            System.out.println("An ArithmeticException occurred: " + e.getMessage());
        }

        try {
            
            int number = parseInt("abc");
            System.out.println("Parsed number: " + number);
        } catch (NumberFormatException e) {
            
            System.out.println("A NumberFormatException occurred: " + e.getMessage());
        }

        System.out.println("Program continues after exception handling");
    }

    
    public static int divide(int numerator, int denominator) {
        return numerator / denominator;
    }

   
    public static int parseInt(String str) {
        return Integer.parseInt(str);
    }
}

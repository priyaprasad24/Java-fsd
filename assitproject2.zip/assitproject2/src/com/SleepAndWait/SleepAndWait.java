package com.SleepAndWait;

public class SleepAndWait {
    public static void main(String[] args) {
        final Object lock = new Object();

        // Thread 1: Using sleep() to pause execution for 2 seconds
        Thread thread1 = new Thread(() -> {
            try {
                System.out.println("Thread 1: Started");
                Thread.sleep(2000); // Sleep for 2 seconds
                System.out.println("Thread 1: Woke up after sleep");
            } catch (InterruptedException e) {
                e.printStackTrace();
            }
        });

        // Thread 2: Using wait() to pause execution until notified
        Thread thread2 = new Thread(() -> {
            synchronized (lock) {
                try {
                    System.out.println("Thread 2: Started and waiting");
                    lock.wait(); // Wait until notified
                    System.out.println("Thread 2: Resumed after notification");
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        });

        thread1.start();
        thread2.start();

        // Sleep for a while to let threads execute
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        synchronized (lock) {
            System.out.println("Main thread: Notifying waiting thread");
            lock.notify(); // Notify the waiting thread
        }
    }
}




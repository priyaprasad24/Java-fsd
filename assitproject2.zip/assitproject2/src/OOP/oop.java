package OOP;

public class oop {
    public static void main(String[] args) {
        Student student1 = new Student("Alice", 20);
        Student student2 = new Student("Bob", 22);

        student1.setAge(21);

        System.out.println("Student 1 Info:");
        student1.displayInfo();
        System.out.println("\nStudent 2 Info:");
        student2.displayInfo();

        GraduateStudent gradStudent = new GraduateStudent("Charlie", 25, "Computer Science");

        System.out.println("\nGraduate Student Info:");
        gradStudent.displayInfo();
    }
}


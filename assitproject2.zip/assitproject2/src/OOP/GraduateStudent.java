package OOP;

class GraduateStudent extends Student {
    private String specialization;

    public GraduateStudent(String name, int age, String specialization) {
        super(name, age);
        this.specialization = specialization;
    }

    @Override
    public void displayInfo() {
        super.displayInfo();
        System.out.println("Specialization: " + specialization);
    }
}


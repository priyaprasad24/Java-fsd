package ExceptionHandling;


class CustomException extends Exception {
 public CustomException(String message) {
     super(message);
 }
}

public class ExceptionHandling {
 // Method that throws an exception using 'throws'
 public static void methodWithThrows() throws CustomException {
     System.out.println("Inside methodWithThrows");
     throw new CustomException("CustomException thrown from methodWithThrows");
 }


 public static void methodWithThrow() {
     System.out.println("Inside methodWithThrow");
     throw new ArithmeticException("ArithmeticException thrown from methodWithThrow");
 }

 public static void main(String[] args) {
     try {
         // Calling a method that uses 'throws' to propagate the exception
         methodWithThrows();
     } catch (CustomException e) {
         System.out.println("Caught CustomException: " + e.getMessage());
     }

     try {
         // Calling a method that uses 'throw' to explicitly throw an exception
         methodWithThrow();
     } catch (ArithmeticException e) {
         System.out.println("Caught ArithmeticException: " + e.getMessage());
     }

     try {
         // Using 'finally' block to ensure cleanup code is executed
         System.out.println("Inside try block");
     } finally {
         System.out.println("Inside finally block");
     }
 }
}



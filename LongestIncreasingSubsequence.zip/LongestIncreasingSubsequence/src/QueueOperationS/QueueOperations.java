package QueueOperationS;

import java.util.LinkedList;
import java.util.Queue;

public class QueueOperations {
    public static void main(String[] args) {
        // Create a queue using LinkedList
        Queue<Integer> queue = new LinkedList<>();

        // Enqueue elements into the queue
        queue.offer(10);
        queue.offer(20);
        queue.offer(30);
        queue.offer(40);

        System.out.println("Queue after enqueue operations: " + queue);

        // Dequeue and display the front element
        int dequeuedElement = queue.poll();
        System.out.println("Dequeued element: " + dequeuedElement);
        System.out.println("Queue after dequeue operation: " + queue);

        // Peek at the front element without removal
        int frontElement = queue.peek();
        System.out.println("Front element without removal: " + frontElement);

        // Check if the queue is empty
        boolean isEmpty = queue.isEmpty();
        System.out.println("Is the queue empty? " + isEmpty);

        // Size of the queue
        int size = queue.size();
        System.out.println("Size of the queue: " + size);
    }
}

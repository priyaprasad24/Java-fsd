package rightRotateArray;

public class RightRotateArray {
    public static void main(String[] args) {
        int[] arr = {1, 2, 3, 4, 5, 6, 7};
        int rotateSteps = 5;

        System.out.println("Original Array:");
        displayArray(arr);

        // Right rotate the array
        rightRotate(arr, rotateSteps);

        System.out.println("Array after right rotation by " + rotateSteps + " steps:");
        displayArray(arr);
    }

    // Function to right rotate an array by 'steps' positions
    public static void rightRotate(int[] arr, int steps) {
        int n = arr.length;
        int[] temp = new int[n];

        // Copy the last 'steps' elements to the temporary array
        for (int i = 0; i < steps; i++) {
            temp[i] = arr[n - steps + i];
        }

        // Shift the remaining elements to the right
        for (int i = 0; i < n - steps; i++) {
            temp[i + steps] = arr[i];
        }

        // Copy the rotated elements back to the original array
        for (int i = 0; i < n; i++) {
            arr[i] = temp[i];
        }
    }

    // Function to display the contents of an array
    public static void displayArray(int[] arr) {
        for (int num: arr) {
            System.out.print(num + " ");
        }
        System.out.println();
    }
}

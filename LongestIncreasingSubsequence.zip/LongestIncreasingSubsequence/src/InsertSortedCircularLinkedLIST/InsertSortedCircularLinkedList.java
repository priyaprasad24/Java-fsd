package InsertSortedCircularLinkedLIST;

class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    Node head;

    CircularLinkedList() {
        head = null;
    }

    // Method to insert a new element into a sorted circular linked list
    void insertSorted(int newData) {
        Node newNode = new Node(newData);
        if (head == null) {
            head = newNode;
            newNode.next = head;
        } else if (newData <= head.data) {
            // Insert at the beginning
            Node last = getLastNode();
            newNode.next = head;
            head = newNode;
            last.next = newNode;
        } else {
            Node current = head;
            while (current.next != head && current.next.data < newData) {
                current = current.next;
            }
            newNode.next = current.next;
            current.next = newNode;
        }
    }

    // Method to get the last node of the circular linked list
    Node getLastNode() {
        Node current = head;
        while (current.next != head) {
            current = current.next;
        }
        return current;
    }

    // Method to display the circular linked list
    void display() {
        if (head == null) {
            System.out.println("The circular linked list is empty.");
            return;
        }
        Node current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);
        System.out.println();
    }
}

public class InsertSortedCircularLinkedList {
    public static void main(String[] args) {
        CircularLinkedList list = new CircularLinkedList();

        list.insertSorted(20);
        list.insertSorted(10);
        list.insertSorted(40);
        list.insertSorted(30);

        System.out.println("Sorted Circular Linked List:");
        list.display();
    }
}


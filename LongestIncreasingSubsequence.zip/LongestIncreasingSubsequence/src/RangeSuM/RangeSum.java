package RangeSuM;

import java.util.Scanner;

public class RangeSum {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);

        // Input the number of elements in the array
        System.out.print("Enter the number of elements (n): ");
        int n = input.nextInt();

        // Initialize the array
        int[] arr = new int[n];

        // Input the array elements
        System.out.println("Enter the elements:");
        for (int i = 0; i < n; i++) {
            arr[i] = input.nextInt();
        }

        // Input the range L and R
        System.out.print("Enter the range (L and R) where 0 <= L <= R <= n-1:\nL = ");
        int L = input.nextInt();
        System.out.print("R = ");
        int R = input.nextInt();

        // Validate the range
        if (L < 0 || R >= n || L > R) {
            System.out.println("Invalid range.");
            return;
        }

        // Calculate the sum of elements in the range [L, R]
        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += arr[i];
        }

        System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sum);
    }
}


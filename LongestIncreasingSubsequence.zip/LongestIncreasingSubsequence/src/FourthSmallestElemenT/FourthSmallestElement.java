package FourthSmallestElemenT;

public class FourthSmallestElement {
    public static void main(String[] args) {
        int[] unsortedList = {12, 4, 7, 9, 2, 23, 15, 8};
        
        int fourthSmallest = findFourthSmallestElement(unsortedList);
        
        System.out.println("Fourth smallest element in the list: " + fourthSmallest);
    }

    public static int findFourthSmallestElement(int[] arr) {
        if (arr.length < 4) {
            System.out.println("List has fewer than four elements.");
            return -1; // Indicate that the result is not found.
        }
        
        // Perform selection sort to find the fourth smallest element.
        for (int i = 0; i < 4; i++) {
            int minIndex = i;
            for (int j = i + 1; j < arr.length; j++) {
                if (arr[j] < arr[minIndex]) {
                    minIndex = j;
                }
            }
            
            // Swap the smallest element found with the element at position 'i'.
            int temp = arr[i];
            arr[i] = arr[minIndex];
            arr[minIndex] = temp;
        }
        
        // The fourth smallest element is now at index 3 (0-based index).
        return arr[3];
    }
}


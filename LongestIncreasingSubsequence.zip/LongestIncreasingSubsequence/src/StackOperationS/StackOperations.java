package StackOperationS;

import java.util.Stack;

public class StackOperations {
    public static void main(String[] args) {
        // Create a stack
        Stack<Integer> stack = new Stack<>();

        // Insert elements into the stack (push)
        stack.push(10);
        stack.push(20);
        stack.push(30);
        stack.push(40);

        System.out.println("Stack after push operations: " + stack);

        // Remove and display the top element (pop)
        int poppedElement = stack.pop();
        System.out.println("Popped element: " + poppedElement);
        System.out.println("Stack after pop operation: " + stack);

        // Peek at the top element without removal
        int topElement = stack.peek();
        System.out.println("Top element without removal: " + topElement);

        // Check if the stack is empty
        boolean isEmpty = stack.isEmpty();
        System.out.println("Is the stack empty? " + isEmpty);

        // Size of the stack
        int size = stack.size();
        System.out.println("Size of the stack: " + size);
    }
}


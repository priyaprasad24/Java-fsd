import java.sql.*;
public class Testconnection {

	public static void main(String[] args) {
		try
		{
		//Registering Driver
		Class.forName("com.mysql.cj.jdbc.Driver");
		//Making Connection 
		Connection  conObj  = DriverManager.getConnection("jdbc:mysql://localhost:3307/priyanewdb", "root", "root");

		if(conObj!=null)
			System.out.println("Connected.....");
		}
		catch(Exception ex)
		{
			System.out.println(ex);
		}
	}

}

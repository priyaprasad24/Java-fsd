package LinearSearch;

public class ExponentialSearch {
    public static void main(String[] args) {
        int[] array = {10, 20, 30, 40, 50, 60, 70};
        int target = 40;

        int result = exponentialSearch(array, target);

        if (result != -1) {
            System.out.println("Element " + target + " found at index " + result);
        } else {
            System.out.println("Element " + target + " not found in the array");
        }
    }

    // Exponential search method
    public static int exponentialSearch(int[] arr, int target) {
        int n = arr.length;
        
        // Check if the first element is the target
        if (arr[0] == target) {
            return 0;
        }

        // Find the range for binary search
        int i = 1;
        while (i < n && arr[i] <= target) {
            i *= 2;
        }

        // Perform binary search within the range
        return binarySearch(arr, target, i / 2, Math.min(i, n - 1));
    }

    // Binary search method
    public static int binarySearch(int[] arr, int target, int left, int right) {
        while (left <= right) {
            int mid = left + (right - left) / 2;

            if (arr[mid] == target) {
                return mid; // Element found, return its index
            } else if (arr[mid] < target) {
                left = mid + 1; // Search the right half
            } else {
                right = mid - 1; // Search the left half
            }
        }

        return -1; // Element not found
    }
}


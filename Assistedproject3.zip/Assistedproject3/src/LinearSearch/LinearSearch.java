package LinearSearch;

public class LinearSearch {
    public static void main(String[] args) {
        int[] array = {10, 20, 30, 40, 50, 60, 70};
        int target = 40;

        int result = linearSearch(array, target);

        if (result != -1) {
            System.out.println("Element " + target + " found at index " + result);
        } else {
            System.out.println("Element " + target + " not found in the array");
        }
    }

    // Linear search method
    public static int linearSearch(int[] arr, int target) {
        for (int i = 0; i < arr.length; i++) {
            if (arr[i] == target) {
                return i; // Element found, return its index
            }
        }
        return -1; // Element not found
    }
}
